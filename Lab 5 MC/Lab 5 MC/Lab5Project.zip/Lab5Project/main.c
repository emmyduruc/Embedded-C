//===========================================================
// Test program UART0 TX 8/N/1 @ 9600 bit/s // LTL 17.5.2020
//===========================================================
// Nathalie Mashal, Hilary Chinoso Ogalagu, Chinedu Emmanuel Duru
#include "inc/tm4c1294ncpdt.h"
#include <stdint.h>
#include <stdio.h>
#include "int_handler.h"
#include <string.h>

volatile unsigned char cmdLineUart[15];
volatile unsigned short int i = 0;
volatile unsigned char gucNewData = 0;
volatile int switchPressed = 0;

void configPortA(void){
    // initialize Port A
    SYSCTL_RCGCGPIO_R |= (1<<0); // switch on clock for Port A
    while((SYSCTL_PRGPIO_R & (1<<0)) == 0); // wait for stable clock
    GPIO_PORTA_AHB_DEN_R |= 0x03; // digital I/O enable for pin PA(1:0)
    GPIO_PORTA_AHB_AFSEL_R |= 0x03; // PA(1:0) set to alternate func
    GPIO_PORTA_AHB_PCTL_R |= 0x00000011; // alternate func is U0Rx+Tx
}

void configUart0(void){
    // initialize UART0
    SYSCTL_RCGCUART_R |= (1<<0); // switch on clock for UART0
    while((SYSCTL_PRUART_R & (1<<0))==0); // wait for stable clock
    UART0_CTL_R &= ~(1<<0); // disable UART0 for config

    // initialize bitrate of 9600 bit per second
    UART0_IBRD_R = 104; // set DIVINT of BRD floor(16MHz/16/9600Hz)
    UART0_FBRD_R = 11; // set DIVFRAC of BRD
    UART0_LCRH_R = 0x00000040; // serial format 7N1
    UART0_CTL_R |= 0x0301; // re-enable UART0

    // UART0 interrupts
    UART0_ICR_R = 0xE7FF;
    UART0_IM_R = 1 << 4;
    NVIC_EN0_R |= 1 << 5;
}

void configLEDSW(void)
{
    SYSCTL_RCGCGPIO_R |= 0x00001121; // => port a, j, f, n gets a clock

    // wait until the port is available
    while ((SYSCTL_RCGCGPIO_R & 0x00001121) == 0)
        ;
    GPIO_PORTN_DEN_R = 0x03; // => enable LED lights D1&D2
    GPIO_PORTN_DIR_R = 0x03; // => set LED lights D1&D2 as output
    GPIO_PORTF_AHB_DEN_R = 0x11; // => enable LED lights D3&D4
    GPIO_PORTF_AHB_DIR_R = 0x11; // => set LED lights D3&D4 as output

    //Digital input & WPU
    GPIO_PORTJ_AHB_DEN_R = 0x01;  // enable SW1( PIN PJ(0))
    GPIO_PORTJ_AHB_DIR_R = 0x00; // set SW1 input
    GPIO_PORTJ_AHB_PUR_R = 0x01; // enable WPU for SW1

    //PORTJ interrupts setting
    GPIO_PORTJ_AHB_IEV_R |= 0x01;

    GPIO_PORTJ_AHB_ICR_R = 0x01;
    GPIO_PORTJ_AHB_IM_R |= 0x01;

    NVIC_EN1_R |= 1 << (51 - 32); // enable UART0 IRQ in NVIC(IRQ 5)
}


void configADC(){
    int waitcycle=0;

    SYSCTL_RCGCGPIO_R |= (1<<4); // PE (AIN0 to AIN2 belong to Port E)
    while(!(SYSCTL_PRGPIO_R & 0x10)); // Ready ?
    SYSCTL_RCGCADC_R |= (1<<0); // ADC0 digital block
    while(!(SYSCTL_PRADC_R & 0x01)); // Ready ?

    // configure AIN0 to AIN2 (= PE(3..1)) as analog inputs
    //GPIO_PORTE_AHB_AFSEL_R |=0x0E; // PE3..3 Alternative Pin Function enable
    //GPIO_PORTE_AHB_DEN_R &= ~0x0E; // PE3..1 disable digital IO
    //GPIO_PORTE_AHB_AMSEL_R |= 0x0E; // PE3..1 enable analog function
    //GPIO_PORTE_AHB_DIR_R &= ~0x0E; // Allow Input PE3 ..1

    // ADC0_SS0 configuration
    ADC0_ACTSS_R &= ~0x0F; // disable all 4 sequencers of ADC0

    SYSCTL_PLLFREQ0_R |= (1<<23); // PLL Power
    while (!(SYSCTL_PLLSTAT_R & 0x01)); // until PLL has locked
    ADC0_CC_R |= 0x01;
    waitcycle++; // PIOSC for ADC sampling clock
    SYSCTL_PLLFREQ0_R &= ~(1<<23); // PLLPoweroff
    ADC0_SSMUX0_R |=    0x00000102; // sequencer 0, channel AIN2,AIN0,AIN1
    ADC0_SSCTL0_R |=0x00000100; // END2 set, sequence length = 3
    ADC0_ACTSS_R |=0x01; // enable sequencer 0 ADC0

}


void main(void){
    // config Port A
    configPortA();
    // config UART0 Rx+Tx
    configUart0();
    //config LED and SW
    configLEDSW();
    //config ADC
    configADC();


    while(1){

    }

}

