/*
 * int_handler.c
 *
 *  Created on: 07.06.2021
 *      Author: nataliemashal
 *      Nathalie Mashal, Hilary Chinoso Ogalagu, Chinedu Emmanuel Duru
 */
#include "inc/tm4c1294ncpdt.h"
#include "int_handler.h"
#include <stdint.h>
#include <stdio.h>

int check_leds() {
    return cmdLineUart[0] == 'l' && cmdLineUart[1] == 'e' && cmdLineUart[2] == 'd' && cmdLineUart[3] == 's' && cmdLineUart[4] == ' ';
}

void cmdToLed(void)
{
    int j;

    if (check_leds()) {
        for (j = 5; j < 16; j++)
        {
            if (cmdLineUart[j] == '+')
            {
                switch (cmdLineUart[++j])
                {
                case '1':
                    GPIO_PORTN_DATA_R |= 0x02;
                    break;
                case '2':
                    GPIO_PORTN_DATA_R |= 0x01;
                    break;
                case '3':
                    GPIO_PORTF_AHB_DATA_R |= 0x10;
                    break;
                case '4':
                    GPIO_PORTF_AHB_DATA_R |= 0x01;
                    break;
                }
            }
            else if (cmdLineUart[j] == '-')
            {
                switch (cmdLineUart[++j])
                {
                case '1':
                    GPIO_PORTN_DATA_R &= ~0x02;
                    break;
                case '2':
                    GPIO_PORTN_DATA_R &= ~0x01;
                    break;
                case '3':
                    GPIO_PORTF_AHB_DATA_R &= ~0x10;
                    break;
                case '4':
                    GPIO_PORTF_AHB_DATA_R &= ~0x01;
                    break;
                }
            }
            else if (cmdLineUart[j] == '~')
            {
                switch (cmdLineUart[++j])
                {
                case '1':
                    GPIO_PORTN_DATA_R ^= 0x02;
                    break;
                case '2':
                    GPIO_PORTN_DATA_R ^= 0x01;
                    break;
                case '3':
                    GPIO_PORTF_AHB_DATA_R ^= 0x10;
                    break;
                case '4':
                    GPIO_PORTF_AHB_DATA_R ^= 0x01;
                    break;
                }

            }
        }
    }
}
void IntHandlerUART0(void)
{
    if (UART0_MIS_R & (1 << 4)) // check whether UART0 Rx interrupt
    {
        UART0_ICR_R |= (1 << 4); // clear interrupt
        if (i >= 15 || UART0_DR_R == 0x0D) // do this if out of the size of array
        {
            cmdLineUart[14] = '\0';
            i = 0;
            cmdToLed();
            printf("%s\n", cmdLineUart);
            memset(cmdLineUart, '\0', sizeof(cmdLineUart));
            fflush(stdout);
        }
        else
        {
            cmdLineUart[i++] = UART0_DR_R;
        }
    }
}

void IntPortJHandler(void)
{


    if (GPIO_PORTJ_AHB_MIS_R & (1 << 0))
    {
        GPIO_PORTJ_AHB_ICR_R |= (1 << 0); // clear interrupt

        // UART0_DR_R = '#';

        float avData;
        int i=0;
        char s[6];

        ADC0_PSSI_R |= 0x01; // Start ADC0

        // while(ADC0_SSFSTAT0_R &(1<<8));// wait for FIFO "NON EMPTY"

        avData=0;

        while (ADC0_SSFSTAT0_R & 0x000000100);


        for ( i=0;i < 4;i++){

            avData += (147.5-(((75*3300)*(unsigned long)ADC0_SSFIFO0_R)/4096000));
            avData /= 4;

        }

        //printf(" TEMP= %d C\n",avData);
        sprintf(s,"TEMP=%.2f C\n", avData);

        for (i = 0; i < 15; i++) {
            while ((UART0_FR_R & (1 << 5)) != 0); // till transmit FIFO empty
            UART0_DR_R = s[i];
            printf("%s", s);

        }





    }
}


