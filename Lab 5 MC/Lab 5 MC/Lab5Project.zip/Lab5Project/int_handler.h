/*
 * int_handler.h
 *
 *  Created on: 07.06.2021
 *      Author: nataliemashal
 *      Nathalie Mashal, Hilary Chinoso Ogalagu, Chinedu Emmanuel Duru
 */

#ifndef INT_HANDLER_H_
#define INT_HANDLER_H_

void IntHandlerUART0(void);
void IntPortJHandler(void);

extern volatile unsigned char gucNewData;
extern volatile unsigned char cmdLineUart[15];
extern volatile unsigned short int i;
extern volatile int switchPressed;

#endif /* INT_HANDLER_H_ */
